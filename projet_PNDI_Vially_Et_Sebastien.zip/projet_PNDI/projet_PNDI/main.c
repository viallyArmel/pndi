#include "Header.h"

void main(void) {

	CLEAN_SCREEN;
	
	Subject subjects[NB_SUBJECTS];
	Status status = getAllSubjects(subjects, NB_SUBJECTS);

	if (status == NO_ERROR) {
		status = createTestSetAndTrainSet(subjects, NB_SUBJECTS);

		if (status == ERROR_OPENING_FILE)
			puts("Erreur de lecture file ! le programme va s'arreter !");
		else if (status == ERROR_CREATION_FILE)
			puts("Erreur de creation de testSet ou de trainSet ! le programme va s'arreter !");
	}
	else
		puts("Erreur de lecture des sujets ! le programme va s'arreter !");

	ligneBlanche(2);
	PAUSE;
	ligneBlanche(1);

}