#include "Header.h"


char paths[NB_PATH][TCH] = {
		"dws_1", "dws_2", "dws_11", "jog_9", "jog_16", "sit_5", "sit_13", "std_6",
		"std_14", "ups_3", "ups_4", "ups_12", "wlk_7", "wlk_8", "wlk_15"
};

void ligneBlanche(int nbFois) {
	for (int i = 0; i < nbFois; i++)
		printf("\n");
}


//a supprimer
void buildPath(char* racine, char* path, char destination[]) {

	strcpy_s(destination, MAX_CHAR, racine);
	strcat_s(destination, MAX_CHAR, path);

}

Status openFile(FILE** file, char* fileName, char* mode) {
	
	fopen_s(file, fileName, mode);
	if (*file == NULL && strcmp(mode, WRITE) == 0) return ERROR_CREATION_FILE;
	return *file == NULL ? ERROR_OPENING_FILE : NO_ERROR;
}

char* skipColumn(char** line, char* currentColumn, int nbTimes) {

	for (int i = 0; i < nbTimes; i++) 
		currentColumn = strtok_s(NULL, ",", line);
	
	return currentColumn;
}

Status getAllSubjects(Subject subjects[], int nbSubjects) {
	FILE* file;

	Status status = openFile(&file, FILE_NAME_SUJECTS, READ);
	if (status == ERROR_OPENING_FILE)
		return status;

	char buffer[BUFFER_SIZE];

	char* line = fgets(buffer, sizeof(buffer), file);
	int iSubject = 0;
	while (!feof(file) && iSubject < NB_SUBJECTS) {

		line = fgets(buffer, sizeof(buffer), file);

		char* col = strtok_s(buffer, ",", &line);
		subjects[iSubject].index = atoi(col);

		col = skipColumn(&line, col, 3);

		col = strtok_s(NULL, ",", &line);
		subjects[iSubject].gender = atoi(col);

		iSubject++;
	}

	fclose(file);
	return status;
}

double getAcceleration(double a1, double a2, double a3) {
	double acc = pow(a1, 2) + pow(a2, 2) + pow(a3, 2);

	return sqrt(acc);
}

void appendChar(char destination[], char* source, bool addComa) {
	strcat_s(destination, strlen(destination), source);
	if (addComa)
		strcat_s(destination, strlen(destination), ",");
}

void appendDouble(char destination[], int sizeDest, double source, bool addComa) {
	char sourceChar[TCH];
	sprintf_s(sourceChar, TCH, "%f", source);
	strcat_s(destination, sizeDest, sourceChar);
	if (addComa) 
		strcat_s(destination, sizeDest, ",");
}

void appendInt(char destination[], int sizeDest, int source, bool addComa) {
	char sourceChar[TCH];
	sprintf_s(sourceChar, TCH, "%d", source);
	strcat_s(destination, sizeDest, sourceChar);
	if (addComa)
		strcat_s(destination, sizeDest, ",");
}

Status createTestSetAndTrainSet(Subject subjects[], int nbSubjects) {
	Status status = NO_ERROR;
	FILE* file;
	FILE* testSetFile;
	FILE* trainSetFile;

	status = openFile(&testSetFile, TESTSET, WRITE);
	if (status == ERROR_CREATION_FILE) return status;
	
	status = openFile(&trainSetFile, TRAINSET, WRITE);
	if (status == ERROR_CREATION_FILE) return status;


	for (int iMvt = 0; iMvt < NB_PATH; iMvt++) {

		char racinePath[MAX_CHAR];
		char fileName[MAX_CHAR];

		strcpy_s(racinePath, MAX_CHAR, RACINE);
		strcat_s(racinePath, MAX_CHAR, paths[iMvt]);
		strcat_s(racinePath, MAX_CHAR, "/sub_");

		srand((unsigned)time(NULL));

		int iSubject = 0;
		while (iSubject < NB_SUBJECTS) {

			char endFileName [MAX_CHAR];
			sprintf_s(endFileName, TCH, "%d", iSubject + 1);
			strcat_s(endFileName, MAX_CHAR, ".csv");
			strcpy_s(fileName, MAX_CHAR, racinePath);
			strcat_s(fileName, MAX_CHAR, endFileName);

			status = openFile(&file, fileName, READ);
			if (status != NO_ERROR)
				return ERROR_OPENING_FILE;

			char lineToSave[BUFFER_SIZE];

			MovementInfo movementInfo;
			strcpy_s(movementInfo.mvtName, TCH, paths[iMvt]);
			movementInfo.index = subjects[iSubject].index;
			movementInfo.gender = subjects[iSubject].gender;

			strcpy_s(lineToSave, BUFFER_SIZE, paths[iMvt]);
			strcat_s(lineToSave, BUFFER_SIZE, ",");
			appendInt(lineToSave, BUFFER_SIZE, movementInfo.index, true);
			appendInt(lineToSave, BUFFER_SIZE, movementInfo.gender, true);

			double acc1, acc2, acc3;
			acc1 = acc2 = acc3 = 0;

			char buffer[BUFFER_SIZE];
			char* line = fgets(buffer, sizeof(buffer), file);
			int iData = 0;

			while (!feof(file) && iData < NB_DATAS) {
				line = fgets(buffer, sizeof(buffer), file);

				char* col = strtok_s(buffer, ",", &line);

				col = skipColumn(&line, col, 8);

				col = strtok_s(NULL, ",", &line);
				if (col != NULL)
					acc1 = atof(col);

				col = strtok_s(NULL, ",", &line);
				if (col != NULL)
					acc2 = atof(col);

				col = strtok_s(NULL, ",", &line);
				if (col != NULL)
					acc3 = atof(col);

				if (col != NULL)
					movementInfo.accelerations[iData] = getAcceleration(acc1, acc2, acc3);

				iData + 1 < NB_DATAS ? appendDouble(lineToSave, BUFFER_SIZE, movementInfo.accelerations[iData], true) : appendDouble(lineToSave, BUFFER_SIZE, movementInfo.accelerations[iData], false);
				iData++;
			}

			int randomNumber = 1 + rand() % 11;
			if (randomNumber == 1) {
				fprintf(testSetFile, "%s\n", lineToSave);
			}
			else {
				fprintf(trainSetFile, "%s\n", lineToSave);
			}

			iSubject++;
		}
	}

	fclose(trainSetFile);
	fclose(testSetFile);

	return status;
}