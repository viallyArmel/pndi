#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <stdbool.h>


#define FILE_NAME_TEST "C:/Users/armel/Desktop/BLOC_2/PNDI/data.csv"
#define FILE_NAME_SUJECTS "C:/Users/armel/Desktop/BLOC_2/PNDI/data_subjects_info.csv"
#define BUFFER_SIZE 7000
#define MAX_CHAR 200
#define NB_PATH 15
#define NB_SUBJECTS 24
#define NB_DATAS 600
#define TCH 30
#define RACINE "C:/Users/armel/Desktop/BLOC_2/PNDI/A_DeviceMotion_data/A_DeviceMotion_data/"
#define READ "r"
#define WRITE "w"
#define PAUSE system("pause")
#define CLEAN_SCREEN system("cls")
#define TRAINSET "trainSet.csv"
#define TESTSET "testSet.csv"

typedef enum status {
	NO_ERROR,
	ERROR_OPENING_FILE,
	ERROR_CREATION_FILE
}Status;

typedef struct subject {
	int index;
	int gender;
}Subject;

typedef struct movementInfo {
	char mvtName[TCH];
	int index;
	int gender;
	double accelerations[NB_DATAS];

}MovementInfo;

Status openFile(FILE** file, char* fileName, char* mode);
void buildPath(char* racine, char* path, char destination[]);
Status getAllSubjects(Subject subjects[], int nbSubjects);
Status createTestSetAndTrainSet(Subject subjects[], int nbSubjects);
void ligneBlanche(int nbFois);